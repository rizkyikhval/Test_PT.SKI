<?php
class Customer extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('customer_model');
        $this->load->helper('url');
    }
    
    public function index() {
        $data['customers'] = $this->customer_model->get_customers();
        $this->load->view('customer_list', $data);
    }
    
    public function add() {
        if ($this->input->post()) {
            $data = array(
                'nama' => $this->input->post('nama'),
                'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                'tanggal_lahir' => $this->input->post('tanggal_lahir'),
                'pekerjaan' => $this->input->post('pekerjaan'),
                'provinsi' => $this->input->post('provinsi'),
                'kab_kota' => $this->input->post('kab_kota'),
                'kecamatan' => $this->input->post('kecamatan'),
                'desa' => $this->input->post('desa')
            );
            $this->customer_model->insert_customer($data);
    
            // Get the updated customer list
            $data['customers'] = $this->customer_model->get_customers();
            $customer_list_html = $this->load->view('customer_list', $data, TRUE);
    
            // Return the updated customer list HTML content
            echo $customer_list_html;
        } else {
            $this->load->view('add_customer');
        }
    }
    
    
    public function edit($id) {
        if ($this->input->post()) {
            $data = array(
                'nama' => $this->input->post('nama'),
                'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                'tanggal_lahir' => $this->input->post('tanggal_lahir'),
                'pekerjaan' => $this->input->post('pekerjaan'),
                'provinsi' => $this->input->post('provinsi'),
                'kab_kota' => $this->input->post('kab_kota'),
                'kecamatan' => $this->input->post('kecamatan'),
                'desa' => $this->input->post('desa')
            );
            $this->customer_model->update_customer($id, $data);
            redirect('customer');
        } else {
            $data['customer'] = $this->customer_model->get_customer_by_id($id);
            $this->load->view('edit_customer', $data);
        }
    }
    
    public function delete($id) {
        $this->customer_model->delete_customer($id);
        redirect('customer');
    }
}
?>
